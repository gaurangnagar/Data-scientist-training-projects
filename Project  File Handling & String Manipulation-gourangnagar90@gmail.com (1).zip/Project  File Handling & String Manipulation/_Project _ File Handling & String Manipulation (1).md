**Project : File Handling & String Manipulation
--------------------------------------------------------------------------------------------------------------------------------------

Q 1. A sample script of Game of Thrones was taken from the page and stored in the file conv.txt in the dataset provided. Your task is to read the file and do the following?


__1. Find out the number of unique characters in the sample conversation?


```python
# In conv.txt file, we observe that the dialogues and characters are separated by a `:`,
# on which we will use split function and append the separated characters in a blank list.

name_list = []

with open('Games of thornes', 'r') as text:
    
    for i in text:
        if i[0]== '\n':
            pass
        else:
            name_list.append(i.split(':')[0])
        
```


```python
name_set = set(name_list)
```


```python
len(name_set)
```




    17


__Total numbers of character in the given Games of thornes list is 17.
**-------------------------------------------------------------------------------------------------------------------------------

Ques 2. Create a new text file for each of the characters with their name and store the unique words said by them in their respective file. Store one word in one line?



```python

# In the given text file we will again split the character and dialogue and append them in a blank list, which will create
# a nested list comprising list of each dialogue along with
# its speaker on the 1st and 0th index respectively.

conversation = []

with open('Games of thornes', 'r') as text:
    
    for i in text:
        if i[0]== '\n':
            pass
        else:
            conversation.append(i.split(': '))
            
```


```python
# Now we will compare the 0th index containing names in "conversation" with the names in "name_set" created in above question
# in a nested for loop. If the 0th index will match, 1st index of that list will be converted to string and
# appended in the blank string "dialogue_str" in each loop.

for i in name_set:
    dialogue_str = ""
    for j in conversation:
        if j[0] == i:
            dialogue_str = dialogue_str+str(j[1])

# Now "dialogue_str" will be cleaned and all the words will be converted to uppercase/ lowercase in order to avoid
# repetition due to case difference and then splitted to individual words.
    
    dialogue_str = dialogue_str.replace('!', '').replace(".","").replace(",","").replace("?", "").upper()
    dialogue_split = dialogue_str.split()

# Convert these individual words present inside "dialogue_split" in to a set for getting unique words named "dialogue_set".
    dialogue_set = set(dialogue_split)
    
# Insert these words from "dialogue_set" using for loop, creating respective text files by creating a file writing path
# in 'w' mode, then close the file for the 'for loop'.
    file = open(i+'.txt','w')
    for k in dialogue_set:
        file.write(k + '\n')
    file.close()
```


```python

```
